let slideShow1 = new slideShow('slideShow1')
slideShow.activeShow = slideShow1
document.addEventListener('slideChanged', (event)=>{
    let detail = event.detail
    if(detail.slideShowId == 'slideShow1'){
        if(detail.slideNumber==1){
            console.log('slideShow1')
            let btnList = document.querySelectorAll('.goToSection');
            console.log(btnList)
            btnList[0].addEventListener('click',()=>{
                slideShow1.goToSlide(2)
            })
            btnList[1].addEventListener('click',()=>{
                slideShow1.goToSlide(4)
            })
            btnList[2].addEventListener('click',()=>{
                slideShow1.goToSlide(7)
            })
            btnList[3].addEventListener('click',()=>{
                slideShow1.goToSlide(9)
            })
        }
        if(detail.slideNumber==10){
            console.log('slideShow1')
            let btnList = document.querySelectorAll('.goToSection');
            console.log(btnList)
            btnList[4].addEventListener('click',()=>{
                slideShow1.goToSlide(11)
            })
            btnList[5].addEventListener('click',()=>{
                slideShow1.goToSlide(14)
            })
            btnList[6].addEventListener('click',()=>{
                slideShow1.goToSlide(20)
            })
            btnList[7].addEventListener('click',()=>{
                slideShow1.goToSlide(25)
            })
        }
    }
})
